const express = require('express');
const axios = require('axios');
const router = express.Router();


router.get('/news', async (req, res) => {
    try {
        const response = await axios.get(`${process.env.NEWS_API_URL}/top-headlines`, {
            params: {
                country: 'us',
                apiKey: process.env.NEWS_API_KEY,
            },
        });
        res.json(response.data.articles);
    } catch (error) {
        console.error('Error fetching news:', error.message);
        res.status(500).json({ error: 'Failed to fetch news' });
    }
});

router.get('/currency', async (req, res) => {
    try {
        const response = await axios.get(`${process.env.CURRENCY_API_URL}/latest`, {
            params: {
                apiKey: process.env.CURRENCY_API_KEY,
            },
        });
        res.json(response.data.rates);
    } catch (error) {
        console.error('Error fetching currency rates:', error.message);
        res.status(500).json({ error: 'Failed to fetch currency rates' });
    }
});



module.exports = router;